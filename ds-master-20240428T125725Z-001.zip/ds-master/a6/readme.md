1. `javac Bully.java`
2. `java Bully`
3. `javac Ring.java`
4. `java Ring`
