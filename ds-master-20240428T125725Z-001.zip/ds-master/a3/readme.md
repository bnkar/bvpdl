1. `sudo apt install mpich`
2. `mpicc mpi.c -o obj`
3. `mpirun -n 4 ./obj`
