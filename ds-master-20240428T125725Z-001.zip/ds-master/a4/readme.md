1. `javac TimeServer.java`
2. `export CLASSPATH=.`
3. `java TimeServer`
