1. `javac TokenRing.java`
2. `java TokenRing`
